Release 0.8.3
-------------

2020-01-26

New Modules
^^^^^^^^^^^


Enhancements
^^^^^^^^^^^^

* Support eapi command revision syntax (`181 <https://github.com/arista-eosplus/pyeapi/pull/181>`_) 

* Add ability to use pyeapi with certificates

* Added check for 'match' statement to be valid before parsing regex ACL

Fixed
^^^^^

Known Caveats
^^^^^^^^^^^^^


