######
v0.2.1
######

2015-03-28

- restores default certificate validation behavior for py2.7.9
