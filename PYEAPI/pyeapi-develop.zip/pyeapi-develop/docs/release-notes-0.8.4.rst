Release 0.8.4
-------------

2020-11-13

New Modules
^^^^^^^^^^^


Enhancements
^^^^^^^^^^^^

* Add streaming capability for eapi interface

* Add Power ppc64le support with CI

Fixed
^^^^^

Known Caveats
^^^^^^^^^^^^^


