######
v0.1.0
######

2015-01-23

- initial public release of pyeapi
- initial support for vlans
- initial support for interfaces
- initial support for spanningtree
- initial support for switchports
- initial support for ipinterfaces
