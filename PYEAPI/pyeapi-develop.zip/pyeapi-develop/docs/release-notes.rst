#############
Release Notes
#############

.. toctree::
    :maxdepth: 2
    :titlesonly:

    release-notes-1.0.3.rst
    release-notes-1.0.2.rst
    release-notes-1.0.0.rst
    release-notes-0.8.4.rst
    release-notes-0.8.3.rst
    release-notes-0.8.2.rst
    release-notes-0.8.1.rst
    release-notes-0.8.0.rst
    release-notes-0.7.0.rst
    release-notes-0.6.1.rst
    release-notes-0.6.0.rst
    release-notes-0.5.0.rst
    release-notes-0.4.0.rst
    release-notes-0.3.3.rst
    release-notes-0.3.2.rst
    release-notes-0.3.1.rst
    release-notes-0.3.0.rst
    release-notes-0.2.4.rst
    release-notes-0.2.3.rst
    release-notes-0.2.2.rst
    release-notes-0.2.1.rst
    release-notes-0.2.0.rst
    release-notes-0.1.1.rst
    release-notes-0.1.0.rst
